package com.avengers.yoribogo.notification.notification.repository;

import org.springframework.stereotype.Repository;

@Repository
public class NotificationRepository {
}
