package com.avengers.yoribogo.user.dto;

public class UserDTO {
}
