package com.avengers.yoribogo.user.controller;

public class UserController {
}
