package com.avengers.yoribogo.recipeboard.domain;

public class RecipeBoardManual {
}
