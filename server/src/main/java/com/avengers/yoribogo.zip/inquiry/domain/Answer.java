package com.avengers.yoribogo.inquiry.domain;

public class Answer {
}
