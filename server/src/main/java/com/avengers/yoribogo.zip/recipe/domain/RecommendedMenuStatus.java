package com.avengers.yoribogo.recipe.domain;

public enum RecommendedMenuStatus {
    ACTIVE, INACTIVE
}
