package com.avengers.yoribogo.recipe.domain;

public class RecipeManual {
}
