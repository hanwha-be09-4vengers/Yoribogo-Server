package com.avengers.yoribogo.recipe.service;

import com.avengers.yoribogo.recipe.dto.AIRecipeDTO;

public interface AIRecipeService {

    // AI 요리 레시피 등록
    AIRecipeDTO registAIRecipe(AIRecipeDTO aiRecipeDTO);

}
