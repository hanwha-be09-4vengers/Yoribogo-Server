package com.avengers.yoribogo.recipe.domain;

public enum Satisfaction {
    GOOD, BAD
}
