package com.avengers.yoribogo.mainquestion.domain;

public class Choice {
}
