package com.avengers.yoribogo.mainquestion.domain;

public class MainQuestion {
}
